import React, { useState, useEffect } from 'react';
import { Text,Platform, View, TouchableOpacity, StyleSheet, Linking, Button } from 'react-native';
import { Camera } from 'expo-camera';
import * as Permissions from 'expo-permissions';
import VideoPlayer from 'expo-video-player'
import { Video } from 'expo-av'
import { Audio } from 'expo-av';
import {Provider} from 'react-redux'
import {Constants} from 'expo'
import axios from "axios"
import {
    handleAndroidBackButton,
    removeAndroidBackButtonHandler
  } from "../functions/BackButton_Config" 
 
  import Spinner from 'react-native-loading-spinner-overlay';
  import * as VideoThumbnails from 'expo-video-thumbnails';
  



import {connect} from "react-redux"

class GalleryVideoPlayer extends React.Component {

  videoSet=null
  thumbnail=null
  
  constructor(props) {
    super(props)
    this.state = {
      caption:this.props.caption,
      url:this.props.url
    }
 
     this.navigateBack=this.navigateBack.bind(this)
   }

   navigateBack=()=>{
    this.props.back()

}


 componentDidMount() {
  handleAndroidBackButton(this.navigateBack);
 }





 render() {
    
    
   console.log("the video played",this.state.url,this.state.caption)

    var self=this
    console.log("in render of GalleryVideoPlay")
    this.videoSet={
        shouldPlay: true,
       resizeMode: Video.RESIZE_MODE_CONTAIN,
        source: {
           uri:self.state.url
              }
          }

    return (
        <View style={{flex:1}}>
      
        <TouchableOpacity
          underlayColor="rgba(200,200,200,0.6)"
          style={{flex:.8}}
       >
          <VideoPlayer videoProps={this.videoSet}
          inFullscreen={true}
                />
            
        </TouchableOpacity>
    <Text style={{flex:.2}}>{this.state.caption}</Text>
        </View>
      
      


    );
    

    }

  





  styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: "flex-start"
    },
    headline: {
      alignSelf: "center",
      fontSize: 18,
      marginTop: 10,
      marginBottom: 30
    },
    videoTile: {
      alignSelf: "center",
      fontSize: 16,
      marginTop: 15
    },
    backgroundVideo: {
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
    },
    buttonStyle:{
       marginBottom:100
    },
    spinnerTextStyle: {
      color: '#FFF'
    }
  });





}

const mapStateToProps = state => {
  return {
    
  };
};

const mapDispatchToProps = dispatch => {
  return {
    putCamera: () => {
      dispatch({
        type: "putCamera",
        payload:""
      });
    },
    Urls:(val) => {
      dispatch({
        type: "Urls",
        payload:val
      });
    }
  };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(GalleryVideoPlayer);
  
