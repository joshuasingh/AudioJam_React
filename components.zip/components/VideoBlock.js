import React, { useState, useEffect } from 'react';
import { Text,Platform, View, TouchableOpacity, StyleSheet, Image, Dimensions ,FlatList} from 'react-native';
import { Camera } from 'expo-camera';
import * as Permissions from 'expo-permissions';
import VideoPlayer from 'expo-video-player'
import { Video } from 'expo-av'
import { Audio } from 'expo-av';
import {Provider} from 'react-redux'
import {Constants} from 'expo'
import axios from "axios"
import {
    handleAndroidBackButton,
    removeAndroidBackButtonHandler
  } from "../functions/BackButton_Config" 
 
  import Spinner from 'react-native-loading-spinner-overlay';
  import * as VideoThumbnails from 'expo-video-thumbnails';
  import { Thumbnail } from 'react-native-thumbnail-video';


import {connect} from "react-redux"

class VideoBlock extends React.Component {

    videoSet=null
  
  constructor(props) {
    super(props)
    this.state = {
      image:this.props.image,
      spinner:true
      
    }
    
   
     this.generateThumbnail=this.generateThumbnail.bind(this)  
}


  
    
      generateThumbnail = async () => {
        console.log("thumbnail called")
      
   
        try {
            const { uri } = await VideoThumbnails.getThumbnailAsync(
              'http://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4',
              {
                time: 15000,
              }
            );
            
            this.setState({image:uri,spinner:false})
           
          } catch (e) {
            console.warn(e);
          }
        
       return 

      };


      componentDidMount()
      {
          //this.generateThumbnail()
      }
 


  

  render() {

    console.log("render of picture block")
  
      if(this.state.spinner)
    {
        return (
          <View  style={{position: 'absolute', top: 0, bottom: 0, left: 0, right: 0}}>
              <Spinner
          visible={this.state.spinner}
          textContent={'Uploading...'}
          textStyle={this.styles.spinnerTextStyle}
        />
          </View>
        );
    }
    else{
        return (
            <View
            
          >
            {/* <Text style={this.styles.itemText}>{item.key}</Text> */}
            <Image source={{ uri:this.state.image}}  style={{position: 'absolute', top: 0, bottom: 0, left: 0, right: 0}}/>
            
             </View>
        );
    }
  
}

  





    styles = StyleSheet.create({
        container: {
          flex: 1,
          marginVertical: 40,
        },
        item: {
          backgroundColor: '#4D243D',
          alignItems: 'center',
          justifyContent: 'center',
          flex: 1,
          margin: 1,
           height: Dimensions.get('window').width /this.numColumns,// approximate a square
        },
        itemInvisible: {
          backgroundColor: 'transparent',
        },
        itemText: {
          color: '#fff',
        },
      });


}

const mapStateToProps = state => {
  return {
    
  };
};

const mapDispatchToProps = dispatch => {
  return {
    putCamera: () => {
      dispatch({
        type: "putCamera",
        payload:""
      });
    }
  };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(VideoBlock);
  
