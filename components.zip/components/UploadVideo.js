import React, { useState, useEffect } from 'react';
import { Text,Platform, View, TouchableOpacity, StyleSheet, Linking, Button,Image,TextInput } from 'react-native';
import { Camera } from 'expo-camera';
import * as Permissions from 'expo-permissions';
import VideoPlayer from 'expo-video-player'
import { Video } from 'expo-av'
import { Audio } from 'expo-av';
import {Provider} from 'react-redux'
import {Constants} from 'expo'
import axios from "axios"
import {
    handleAndroidBackButton,
    removeAndroidBackButtonHandler
  } from "../functions/BackButton_Config" 
 
  import Spinner from 'react-native-loading-spinner-overlay';
  import * as VideoThumbnails from 'expo-video-thumbnails';
  import {StackActions,NavigationActions} from "react-navigation"



import {connect} from "react-redux"

class UploadVideo extends React.Component {

  videoSet=null
  thumbnail=null
  
  
  constructor(props) {
    super(props)
    this.state = {
     spinner:false,
      caption:""
     }
    
    
     this.uploadVideo=this.uploadVideo.bind(this)
      this.navigateBack=this.navigateBack.bind(this)
    }



   navigateBack=()=>{
    this.props.putCamera()
    this.props.navigation.goBack()
   }


   componentDidMount() {
    handleAndroidBackButton(this.navigateBack);
 }
  componentWillUnmount() {
   removeAndroidBackButtonHandler();
  }


  




   
  uploadVideo=async()=>{
    console.log("upload called")
    const uri=this.props.VideoInfo.videoUrl
    const codec = "mp4"  
    const type = `video/${codec}`;
  
    const data = new FormData();
    data.append("file", {
      name: "mobile-video-upload",
      type,
      uri
    });

    data.append("file", {
        name: "thumbnail-pic",
        type,
        uri:this.props.VideoInfo.thumbnailUrl
      });
    data.append("file",this.props.UserInfo.userId);
    data.append("file",this.state.caption);

        
    axios.post("http://192.168.1.203:8081/UploadVideo", data)
    .then(response => {
       console.log("done",response.data);
     
        this.props.setUserData(response.data.result)
        this.props.putCamera()
         this.props.navigation.goBack()
      
    }).catch(error => {console.log("error cou",error)});
 
    return 

}

 //get back to main screen
//     navigateBack=()=>{
//     console.log("back called on face")
//     var navActions = StackActions.reset({
    
//       index: 0,
//       actions: [NavigationActions.navigate({routeName:"Profile"})]
//   });
//   this.props.navigation.dispatch(navActions);

// }




  render() {

    console.log("in render of upload")

    return (
        <View style={{flex:1,marginVertical:20}}>
        <Spinner
          visible={this.state.spinner}
          textContent={'Uploading...'}
          textStyle={this.styles.spinnerTextStyle}
          />
        <Image source={{ uri:this.props.VideoInfo.thumbnailUrl}}  style={{ flex:.6}}/>
         <TextInput placeholder="enter the caption" style={{flex:.2}} 
          value={this.state.caption}
         onChangeText={(e)=>{this.setState({caption:e})}}></TextInput>
         <Button title="upload" style={{flex:.2}} onPress={this.uploadVideo}/>
          </View>


    );
    

    }

    componentDidUpdate=()=>
    {
      
    }

  





  styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: "flex-start"
    },
    headline: {
      alignSelf: "center",
      fontSize: 18,
      marginTop: 10,
      marginBottom: 30
    },
    videoTile: {
      alignSelf: "center",
      fontSize: 16,
      marginTop: 15
    },
    backgroundVideo: {
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
    },
    buttonStyle:{
       marginBottom:100
    },
    spinnerTextStyle: {
      color: '#FFF'
    
    }
  });





}

const mapStateToProps = state => {
  return {
    VideoInfo:state.VideoInfo,
    UserInfo:state.UserInfo
  };
};

const mapDispatchToProps = dispatch => {
  return {
    putCamera: () => {
      dispatch({
        type: "putCamera",
        payload:""
      });
    },
    setUserData: (val) => {
        dispatch({
          type: "setUserData",
          payload:val
        });
      },
    putCamera: () => {
        dispatch({
          type: "putCamera",
          payload:""
        });
      }
  };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(UploadVideo);
  
