import React, { useState, useEffect } from 'react';
import { Text,Platform, View, TouchableOpacity, StyleSheet, Linking, Button } from 'react-native';
import { Camera } from 'expo-camera';
import * as Permissions from 'expo-permissions';
import VideoPlayer from 'expo-video-player'
import { Video } from 'expo-av'
import { Audio } from 'expo-av';
import {Provider} from 'react-redux'
import {Constants} from 'expo'
import axios from "axios"
import {
    handleAndroidBackButton,
    removeAndroidBackButtonHandler
  } from "../functions/BackButton_Config" 
 
  import Spinner from 'react-native-loading-spinner-overlay';
  import * as VideoThumbnails from 'expo-video-thumbnails';
  



import {connect} from "react-redux"

class VideoPlay extends React.Component {

  videoSet=null
  thumbnail=null
  
  constructor(props) {
    super(props)
    this.state = {
      videoUrl:this.props.videoUrl,
      spinner:false,
      url:null
    }
    
    this.navigateBack=this.navigateBack.bind(this)
    this.generateThumbnail=this.generateThumbnail.bind(this)

 
   }


  navigateBack=()=>{
      this.props.putCamera()

  }


   componentDidMount() {
    handleAndroidBackButton(this.navigateBack);
  }
  componentWillUnmount() {
    console.log("unmount of video play")

    removeAndroidBackButtonHandler();
  }




  generateThumbnail = async () => {
    console.log("thumbnail called")
   
  
    try {
        const { uri } = await VideoThumbnails.getThumbnailAsync(
          this.props.videoUrl,
          {
            time: 15000,
          }
        );
        
        this.setState({url:uri})       
       
      
      } catch (e) {
        console.warn(e);
      }
 
    
 
  return 

  };





   
  uploadVideo=()=>{
    // const uri=this.props.videoUrl
    // const codec = "mp4"  
    // const type = `video/${codec}`;
  
    // const data = new FormData();
    // data.append("file", {
    //   name: "mobile-video-upload",
    //   type,
    //   uri
    // });

    // this.setState({spinner:true})
    
    // setTimeout(() => {
    //   this.setState({spinner:false})
    
    //   console.log('Hello, World!')
    // }, 4000);
   

 
    // axios.post("http://192.168.1.203:8081/upload", data)
    // .then(response => {
    //    console.log("done",response);
      
    // }).catch(error => {console.log("error cou",error)});
      this.generateThumbnail()
      

   // this.props.navigation.navigate('Music')


    console.log("uploading video",this.thumbnail)
  }

  componentDidUpdate()
  {
    if(this.state.url!==null)
    {
      this.props.Urls({url:this.props.videoUrl,thumbnail:this.state.url})
      this.props.navigation.navigate('upload')
    
    }

  }


  render() {
    
    


    var self=this
    console.log("in render of VideoPlay",this.props.videoUrl,this.state.url)
    this.videoSet={
        shouldPlay: true,
       resizeMode: Video.RESIZE_MODE_CONTAIN,
        source: {
           uri:self.props.videoUrl
              }
          }

    return (
        <View style={{flex:1}}>
        <Spinner
          visible={this.state.spinner}
          textContent={'Uploading...'}
          textStyle={this.styles.spinnerTextStyle}
        />
        <View style={{flex:.8}}>
        <TouchableOpacity
          underlayColor="rgba(200,200,200,0.6)"
       >
          <VideoPlayer videoProps={this.videoSet}
          inFullscreen={true}
                />
            
        </TouchableOpacity>
        </View>
       <View style={{flex:.2}}>
        <Button   style={this.styles.buttonStyle} title="Upload Video" onPress={this.generateThumbnail}/>
        </View>
      </View>


    );
    

    }

  





  styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: "flex-start"
    },
    headline: {
      alignSelf: "center",
      fontSize: 18,
      marginTop: 10,
      marginBottom: 30
    },
    videoTile: {
      alignSelf: "center",
      fontSize: 16,
      marginTop: 15
    },
    backgroundVideo: {
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
    },
    buttonStyle:{
       marginBottom:100
    },
    spinnerTextStyle: {
      color: '#FFF'
    }
  });





}

const mapStateToProps = state => {
  return {
    
  };
};

const mapDispatchToProps = dispatch => {
  return {
    putCamera: () => {
      dispatch({
        type: "putCamera",
        payload:""
      });
    },
    Urls:(val) => {
      dispatch({
        type: "Urls",
        payload:val
      });
    }
  };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(VideoPlay);
  
